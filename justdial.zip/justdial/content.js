function injectJs(link) 
{
	var scr = document.createElement("script");
	scr.type="text/javascript";
	scr.src=link;
	(document.head || document.body || document.documentElement).appendChild(scr);
}

injectJs(chrome.extension.getURL("/ui.js"));
injectJs(chrome.extension.getURL("/crm.js"));

var web_path = "http://localhost/justdial/services/fetch_vendor.php";

window.addEventListener('message', function(event) {
	var action = event["data"]["type"];	
    
	if(action == "addVendor")
	{
		var store_name = event["data"]["store"];	
		var rating = event["data"]["rating"];
        var img = event["data"]["img"];
        var addr = event["data"]["addr"];
        var ser = event["data"]["ser"];
        var ref = event["data"]["ref"];
        var surl = event["data"]["surl"];
		
		var xmlhttp = new XMLHttpRequest();	
		xmlhttp.onreadystatechange = function() {				
			if(this.readyState == 4 && this.status == 200)
                console.log("success");            
		};
        
        xmlhttp.open("POST", web_path, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");       xmlhttp.send("action=addVendor&store="+store_name+"&ratings="+rating+"&img="+img+"&addr="+addr+"&ser="+ser+"&ref="+ref+"&surl="+surl);
    }
});