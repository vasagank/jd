<?php
header('Access-Control-Allow-Origin: *'); 
date_default_timezone_set('Asia/Kolkata');

define('_DB_SERVER_', 'localhost');
define('_DB_USER_', 'root');
define('_DB_PASSWORD_', '');
define('_DB_NAME_', 'justdial');

$conn = mysqli_connect(_DB_SERVER_, _DB_USER_, _DB_PASSWORD_, _DB_NAME_);
if(mysqli_connect_errno())
	die();

if(isset($_POST) && $_POST["action"] == "addVendor")
{
    $store_name = preg_replace('/\s+/', ' ', $_POST["store"]);
    $ratings = preg_replace('/\s+/', ' ', $_POST["ratings"]);
    $img_url = preg_replace('/\s+/', ' ', $_POST["img"]);
    $address = preg_replace('/\s+/', ' ', $_POST["addr"]);
    $services = preg_replace('/\s+/', ' ', $_POST["ser"]);
    $surl = preg_replace('/\s+/', ' ', $_POST["surl"]);
    $ref = preg_replace('/\s+/', ' ', $_POST["ref"]);

    $vendor_ref = "";
    $where = " and store_name = '".$store_name."' ";
    if($ref != "")
    {
        $surlArr = explode("'", $ref);
        if(count($surlArr) > 0)
        {
            $vendor_ref = $surlArr[7];
            $where = " and ref = '".$vendor_ref."' ";
        }            
    }

    $sql = "select ref
            from vendor 
            where 1 ".$where." limit 0, 1";

    $result = mysqli_query($conn, $sql);	
    $num_rows = mysqli_num_rows($result);

    if($num_rows < 1)
    {		
        $sqlI = "insert into vendor (ref, store_name, rating, image_url, address, services, alias, insert_time) values ('".$vendor_ref."', '".$store_name."', '".$ratings."', '".$img_url."', '".$address."', '".$services."', '".$surl."', '".date("Y-m-d H:i:s")."')";

        $status = 1;
        $msg = "Success ".$store_name. " -- ".$vendor_ref;

        if(!mysqli_query($conn, $sqlI)) 
        {
            $status = 0;			
            $msg =  $store_name." => Error inserting vendor : ".mysqli_error($conn);
        }

        $response = array("status" => $status, "msg" => "msg =>  ".$msg);
        die(json_encode($response));
    }
    else
    {
        $response = array("status" => 0, "msg" => $vendor_ref." Already Exist"." -- ".$store_name);
        die(json_encode($response));
    }
}
else
{
    $response = array("status" => 0, "msg" => "Invalid action");
    die(json_encode($response));
}

?>