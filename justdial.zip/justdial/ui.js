var link = "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js";
var scr = document.createElement("script");

scr.type = "text/javascript";
scr.src = link;
(document.head || document.body || document.documentElement).appendChild(scr);

setInterval(function(){ readData() }, 25000);

$(document).ready(function() {	
    setTimeout(function() {
        readData();		
    }, 2000);	
});

var store_name, aurl, addr, rating, votes, services, single_page_url, ref;

function readData()
{	
    $('.sp-detail').each(function (i, newRow) {
        
        store_name = $(this).find('.lng_cont_name').text();
        aurl = $(this).find('a').attr("href");
        addr = $(this).find('.cont_fl_addr').text(); 
        rating = $(this).find(".green-box").text();
        votes = $(this).find(".lng_vote").text();
        services = $(this).find(".addrinftxt").text();
        ref = $(this).find('a').attr("onclick");
        single_page_url = $(this).find("a").attr("href");
        
        //console.log(store_name+" -- "+rating+" -- "+aurl+" -- "+addr+" -- "+votes + " -- "+ref+" -- "+single_page_url);
        
        window.postMessage({type :"addVendor", store:store_name, rating:rating, img:aurl, addr:addr, ser:services, ref:ref, surl:single_page_url},'*');
	});    
}